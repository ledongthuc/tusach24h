-- MySQL dump 10.13  Distrib 5.5.25, for Linux (x86_64)
--
-- Host: localhost    Database: tusach24_ts
-- ------------------------------------------------------
-- Server version	5.5.25-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookmark`
--

DROP TABLE IF EXISTS `bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookmark` (
  `BookMarkID` int(11) NOT NULL AUTO_INCREMENT,
  `TruyenID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `BookMarkDate` datetime NOT NULL,
  PRIMARY KEY (`BookMarkID`),
  KEY `BookMark_truyen1` (`TruyenID`),
  KEY `BookMark_user1` (`UserID`),
  CONSTRAINT `BookMark_truyen1` FOREIGN KEY (`TruyenID`) REFERENCES `truyen` (`TruyenID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `BookMark_user1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmark`
--

LOCK TABLES `bookmark` WRITE;
/*!40000 ALTER TABLE `bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `CategoryID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  PRIMARY KEY (`CategoryID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`CategoryID`, `Title`) VALUES (1,'Test Category');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `CommentID` int(11) NOT NULL AUTO_INCREMENT,
  `Content` text NOT NULL,
  `PostedDate` datetime NOT NULL,
  `TruyenID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  PRIMARY KEY (`CommentID`),
  KEY `CommentTruyen1` (`TruyenID`),
  KEY `comment_user1` (`UserID`),
  CONSTRAINT `CommentTruyen1` FOREIGN KEY (`TruyenID`) REFERENCES `truyen` (`TruyenID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `comment_user1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `GroupID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(45) NOT NULL,
  PRIMARY KEY (`GroupID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
INSERT INTO `group` (`GroupID`, `Title`) VALUES (1,'long');
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_cookies`
--

DROP TABLE IF EXISTS `login_cookies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_cookies` (
  `UserID` int(11) NOT NULL,
  `UserCode` varchar(50) NOT NULL,
  `Date` datetime NOT NULL,
  PRIMARY KEY (`UserID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_cookies`
--

LOCK TABLES `login_cookies` WRITE;
/*!40000 ALTER TABLE `login_cookies` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_cookies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `MessageID` int(11) NOT NULL AUTO_INCREMENT,
  `Content` text NOT NULL,
  `PostedDate` datetime NOT NULL,
  `UserID` int(11) NOT NULL,
  PRIMARY KEY (`MessageID`),
  KEY `MessageUser1` (`UserID`),
  CONSTRAINT `MessageUser1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `PageID` int(11) NOT NULL AUTO_INCREMENT,
  `Content` text NOT NULL,
  `TruyenID` int(11) NOT NULL,
  `Chapter` int(11) NOT NULL,
  `Order` int(5) NOT NULL,
  PRIMARY KEY (`PageID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` (`PageID`, `Content`, `TruyenID`, `Chapter`, `Order`) VALUES (1,'<p>\n	Trang 1</p>\n',3,6,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `truyen`
--

DROP TABLE IF EXISTS `truyen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `truyen` (
  `TruyenID` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(225) NOT NULL,
  `Author` varchar(225) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `PostedDate` datetime NOT NULL,
  `Update` datetime NOT NULL,
  `Status` varchar(60) NOT NULL,
  `Source` varchar(60) NOT NULL,
  `Description` text NOT NULL,
  `Content` varchar(45) NOT NULL,
  `CategoryID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `View` int(11) NOT NULL,
  `Like` int(11) NOT NULL,
  `Chapters` int(5) NOT NULL,
  PRIMARY KEY (`TruyenID`),
  KEY `TruyenCategory` (`CategoryID`),
  KEY `TruyenUser1` (`UserID`),
  CONSTRAINT `TruyenCategory` FOREIGN KEY (`CategoryID`) REFERENCES `category` (`CategoryID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `TruyenUser1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `truyen`
--

LOCK TABLES `truyen` WRITE;
/*!40000 ALTER TABLE `truyen` DISABLE KEYS */;
INSERT INTO `truyen` (`TruyenID`, `Title`, `Author`, `Image`, `PostedDate`, `Update`, `Status`, `Source`, `Description`, `Content`, `CategoryID`, `UserID`, `View`, `Like`, `Chapters`) VALUES (4,'BÃ¬nh ngÃ´ Ä‘áº¡i cÃ¡o','ToÃ n','','2012-08-15 16:44:05','0000-00-00 00:00:00','0','3aaewykbhcvj9z','ai biáº¿t Ä‘Ã¢u','',1,1,0,0,2),(7,'Test Story','Test Author','lseknvdx5wsg0j.png','2012-08-16 13:51:32','0000-00-00 00:00:00','0','','very interesting','',1,1,0,0,5);
/*!40000 ALTER TABLE `truyen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(45) NOT NULL,
  `Password` varchar(45) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `CreatedDate` date NOT NULL,
  `GroupID` int(11) NOT NULL,
  `Gender` varchar(45) NOT NULL,
  `Status` int(11) NOT NULL,
  PRIMARY KEY (`UserID`),
  KEY `UserGroup1` (`GroupID`),
  CONSTRAINT `UserGroup1` FOREIGN KEY (`GroupID`) REFERENCES `group` (`GroupID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`UserID`, `Username`, `Password`, `Email`, `CreatedDate`, `GroupID`, `Gender`, `Status`) VALUES (1,'admin','','','0000-00-00',1,'',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-10-02  0:53:52
